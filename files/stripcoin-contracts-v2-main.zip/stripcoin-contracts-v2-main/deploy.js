const { run, ethers, upgrades } = require("hardhat");

require("dotenv").config();

const deployContract = async (contractName, args) => {
  console.log(`⌛ Deploying ${contractName}...`);

  const consumerFactory = await ethers.getContractFactory(contractName);
  const contract = await consumerFactory.deploy(...args);
  await contract.deployed();

  await new Promise((resolve) => {
    setTimeout(resolve, 5000);
  });

  await run("verify:verify", {
    address: "0xaa07aa068bc94169328c38ca692f81304b38e398",
    constructorArguments: args,
  });
  console.log(`✅ Deployed ${contractName} to ${contract.address}`);
};

const deployVestingByProxy = async (contractName, args) => {
  console.log(`⌛ Deploying ${contractName}...`);

  const consumerFactory = await ethers.getContractFactory(contractName);
  const instance = await upgrades.deployProxy(consumerFactory, args);
  await instance.deployed();

  let proxyAddress = instance.address;
  const jsonRinkebyData = require("./.openzeppelin/rinkeby.json");
  const jsonRinkebyDataArray = Object.keys(jsonRinkebyData.impls).map((key) => [
    key,
    jsonRinkebyData.impls[key],
  ]);
  const currentImplAddress =
    jsonRinkebyDataArray[jsonRinkebyDataArray.length - 1][1].address;

  console.log(`✅ Deployed Proxy to ${proxyAddress}`);

  await run("verify:verify", {
    address: currentImplAddress,
    constructorArguments: [],
  });
  console.log(`✅ Deployed ${contractName} to ${currentImplAddress}`);
};

const IS_DEV = process.env.NETWORK == "rinkeby";
const multiSigAdmin = IS_DEV
  ? "0x3808FEa8F5861888a4f8144AF7e2020fDA598Cbe"
  : "";
const stripTokenAddr = IS_DEV
  ? "0x81f53c86E7EE24Cdc499b87c4C6A9b1De6F3d172"
  : "";
const presaleAddr = IS_DEV ? "0xA90123595CCf91862e727B6E6dC44D81045dE9B8" : "";
const proxyAdmin = IS_DEV ? "0xdc72130c10331147F76ff04EcdF78E9823f55B60" : "";
const pVestingAddr = IS_DEV ? "0x0B81Ee8FBFF7389787DaC47d991375f46DFcd82b" : ""; // Vesting contract address deployed by proxy
const vestingAddr = IS_DEV ? "0xaa07aa068bc94169328c38ca692f81304b38e398" : ""; // Vesting contract address deployed without proxy

async function main() {
  // Deploy StripToken contract
  if (!stripTokenAddr) {
    await deployContract("StripToken", []);
  }

  // Deploy Presale contract
  if (!presaleAddr) {
    await deployContract("Presale", [stripTokenAddr, multiSigAdmin]);
  }

  // Deploy Vesting contract
  if (!vestingAddr) {
    await deployContract("Vesting", [
      stripTokenAddr,
      presaleAddr,
      multiSigAdmin,
    ]);
  }

  // Deploy Proxyed Vesting contract
  if (!pVestingAddr) {
    await deployVestingByProxy("Vesting", [
      stripTokenAddr,
      presaleAddr,
      multiSigAdmin,
    ]);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
