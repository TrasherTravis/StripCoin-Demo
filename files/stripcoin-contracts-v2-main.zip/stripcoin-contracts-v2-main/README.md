Contracts for Strip including

- StripToken
